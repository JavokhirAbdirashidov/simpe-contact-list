package com.example.leo.contactlist;


import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.app.Fragment;
//import android.support.v4.app.ListFragment;
import android.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ContactList extends ListFragment {


  Contact contacts[] = new Contact[6];

  String[] firstName = {
    "Javokhir",
    "Daler",
    "Tom",
    "Lionel",
    "Jonny",
    "Bill"
  };

  String[] secondName = {
    "Abdirashidov",
    "Abdullaev",
    "Cruise",
    "Messi",
    "Depth",
    "Gates"
  };
  int[] contactNumber = {
    903232425,
    946171163,
    977771707,
    998184813,
    909901213,
    935673489
  };

  Integer[] imgid={
    R.drawable.img2,
    R.drawable.img2,
    R.drawable.img1,
    R.drawable.img1,
    R.drawable.img2,
    R.drawable.img1,
  };

  public ContactList() {
    // Required empty public constructor
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container,
                           Bundle savedInstanceState) {
    // Inflate the layout for this fragment
    for (int i = 0; i < imgid.length; i++) {
      contacts[i] = new Contact(
        firstName[i],
        secondName[i],
        contactNumber[i],
        imgid[i]
      );
    }
    View view = inflater.inflate(R.layout.fragment_contact_list, container, false);
    CustomListAdapter adapter = new CustomListAdapter(this.getActivity(), contacts);
    setListAdapter(adapter);
    return view;
  }

  @Override
  public void onListItemClick(ListView l, View v, int position, long id) {
    super.onListItemClick(l, v, position, id);

    if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
      Intent intent = new Intent(getActivity(), DetailActivity.class);
      intent.putExtra("first", contacts[position].getFirstName());
      intent.putExtra("second", contacts[position].getLastName());
      intent.putExtra("phone", String.valueOf(contacts[position].getContactNumber()));
      intent.putExtra("image", contacts[position].getImage());
      startActivity(intent);
    }
    if (getResources().getConfiguration().orientation ==
      Configuration.ORIENTATION_LANDSCAPE) {
      DetailFragment detail = (DetailFragment) getFragmentManager().findFragmentById(R.id.detailFrag);
      detail.change(
        contacts[position].getFirstName(),
        contacts[position].getLastName(),
        String.valueOf(contacts[position].getContactNumber()),
        contacts[position].getImage()

      );


      getListView().setSelector(R.color.selectedList);

    }



  }
}
