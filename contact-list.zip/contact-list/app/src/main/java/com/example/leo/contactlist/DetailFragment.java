package com.example.leo.contactlist;


import android.content.res.Configuration;
import android.os.Bundle;
import android.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailFragment extends android.app.Fragment {
  TextView firstName, secondName, phoneNumber;
  ImageView detailImage;

  public DetailFragment() {
    // Required empty public constructor
  }


  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container,
                           Bundle savedInstanceState) {
    // Inflate the layout for this fragment

    View view = inflater.inflate(R.layout.fragment_detail, container, false);
    firstName = view.findViewById(R.id.firstText);
    secondName = view.findViewById(R.id.secondText);
    phoneNumber = view.findViewById(R.id.phoneText);
    detailImage = view.findViewById(R.id.detailImage);

    return view;
  }

  public void change(String first, String second, String phone, int imageView1) {
    firstName.setText("First name: "+first);
    secondName.setText("Last name: "+second);
    phoneNumber.setText("Phone number: "+phone);
    detailImage.setImageResource(imageView1);

    if (getResources().getConfiguration().orientation ==
            Configuration.ORIENTATION_PORTRAIT) {
      int width = (int) getResources().getDimension(R.dimen.imageview_width);
      int height = (int) getResources().getDimension(R.dimen.imageview_height);
      LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(width, height);
      parms.gravity=Gravity.CENTER;
      parms.setMargins(0,20,0,20);
      detailImage.setLayoutParams(parms);

    }

  }

}
