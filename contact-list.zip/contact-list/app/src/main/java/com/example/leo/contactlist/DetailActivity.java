package com.example.leo.contactlist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DetailActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_detail);
    Intent intent = getIntent();
    DetailFragment detail = (DetailFragment) getFragmentManager().findFragmentById(R.id.detailPart);
    detail.change(
      intent.getStringExtra("first"),
      intent.getStringExtra("second"),
      intent.getStringExtra("phone"),
      intent.getIntExtra("image", 0)
    );
  }
}
