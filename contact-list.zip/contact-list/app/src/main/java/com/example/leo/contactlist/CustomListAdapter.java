package com.example.leo.contactlist;

import android.app.Activity;
import android.widget.ArrayAdapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.leo.contactlist.R;

public class CustomListAdapter extends ArrayAdapter {


  private final Activity context;
//  private final String[] itemname;
//  private final Integer[] imgid;
  private final Contact contacts[];
  public CustomListAdapter(Activity context, Contact[] contacts) {
    super(context, R.layout.custom_list_view, contacts);

    this.context = context;
    this.contacts = contacts;
  }


  public View getView(int position, View view, ViewGroup parent) {
    LayoutInflater inflater = context.getLayoutInflater();
    View rowView = inflater.inflate(R.layout.custom_list_view, null, true);

    TextView txtTitle = (TextView) rowView.findViewById(R.id.item);
    ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
    TextView extratxt = (TextView) rowView.findViewById(R.id.textView1);


    txtTitle.setText(contacts[position].getFullName());
    imageView.setImageResource(contacts[position].getImage());
    extratxt.setText("" + contacts[position].getContactNumber());
    return rowView;

  }

  ;
}
