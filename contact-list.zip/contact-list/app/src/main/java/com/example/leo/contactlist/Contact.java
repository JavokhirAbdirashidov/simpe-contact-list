package com.example.leo.contactlist;

public class Contact {
  String firstName;
  String lastName;
  int contactNumber;
  int image;

  public Contact(String firstName, String lastName, int contactNumber, int image) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.contactNumber = contactNumber;
    this.image = image;
  }

  public String getFirstName() {

    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public int getContactNumber() {
    return contactNumber;
  }

  public void setContactNumber(int contactNumber) {
    this.contactNumber = contactNumber;
  }

  public int getImage() {
    return image;
  }

  public void setImage(int image) {
    this.image = image;
  }

  public String getFullName() {
    return this.firstName + " " + this.lastName;
  }

}
